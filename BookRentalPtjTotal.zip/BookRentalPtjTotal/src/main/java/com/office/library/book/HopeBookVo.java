package com.office.library.book;


public class HopeBookVo {

	int hb_no;
	String hb_name;
	String hb_author;
	String hb_publisher;
	String hb_publish_year;
	String hb_reg_date;
	String hb_mod_date;
	int hb_result;
	String hb_result_last_date;
	
	int u_m_no;
	String u_m_id;
	String u_m_pw;
	String u_m_name;
	String u_m_gender;
	String u_m_mail;
	String u_m_phone;
	String u_m_reg_date;
	String u_m_mod_date;
	public int getHb_no() {
		return hb_no;
	}
	public void setHb_no(int hb_no) {
		this.hb_no = hb_no;
	}
	public String getHb_name() {
		return hb_name;
	}
	public void setHb_name(String hb_name) {
		this.hb_name = hb_name;
	}
	public String getHb_author() {
		return hb_author;
	}
	public void setHb_author(String hb_author) {
		this.hb_author = hb_author;
	}
	public String getHb_publisher() {
		return hb_publisher;
	}
	public void setHb_publisher(String hb_publisher) {
		this.hb_publisher = hb_publisher;
	}
	public String getHb_publish_year() {
		return hb_publish_year;
	}
	public void setHb_publish_year(String hb_publish_year) {
		this.hb_publish_year = hb_publish_year;
	}
	public String getHb_reg_date() {
		return hb_reg_date;
	}
	public void setHb_reg_date(String hb_reg_date) {
		this.hb_reg_date = hb_reg_date;
	}
	public String getHb_mod_date() {
		return hb_mod_date;
	}
	public void setHb_mod_date(String hb_mod_date) {
		this.hb_mod_date = hb_mod_date;
	}
	public int getHb_result() {
		return hb_result;
	}
	public void setHb_result(int hb_result) {
		this.hb_result = hb_result;
	}
	public String getHb_result_last_date() {
		return hb_result_last_date;
	}
	public void setHb_result_last_date(String hb_result_last_date) {
		this.hb_result_last_date = hb_result_last_date;
	}
	public int getU_m_no() {
		return u_m_no;
	}
	public void setU_m_no(int u_m_no) {
		this.u_m_no = u_m_no;
	}
	public String getU_m_id() {
		return u_m_id;
	}
	public void setU_m_id(String u_m_id) {
		this.u_m_id = u_m_id;
	}
	public String getU_m_pw() {
		return u_m_pw;
	}
	public void setU_m_pw(String u_m_pw) {
		this.u_m_pw = u_m_pw;
	}
	public String getU_m_name() {
		return u_m_name;
	}
	public void setU_m_name(String u_m_name) {
		this.u_m_name = u_m_name;
	}
	public String getU_m_gender() {
		return u_m_gender;
	}
	public void setU_m_gender(String u_m_gender) {
		this.u_m_gender = u_m_gender;
	}
	public String getU_m_mail() {
		return u_m_mail;
	}
	public void setU_m_mail(String u_m_mail) {
		this.u_m_mail = u_m_mail;
	}
	public String getU_m_phone() {
		return u_m_phone;
	}
	public void setU_m_phone(String u_m_phone) {
		this.u_m_phone = u_m_phone;
	}
	public String getU_m_reg_date() {
		return u_m_reg_date;
	}
	public void setU_m_reg_date(String u_m_reg_date) {
		this.u_m_reg_date = u_m_reg_date;
	}
	public String getU_m_mod_date() {
		return u_m_mod_date;
	}
	public void setU_m_mod_date(String u_m_mod_date) {
		this.u_m_mod_date = u_m_mod_date;
	}
	
	
	
}
