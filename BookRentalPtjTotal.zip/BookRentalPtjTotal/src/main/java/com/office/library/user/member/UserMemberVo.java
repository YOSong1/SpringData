package com.office.library.user.member;


public class UserMemberVo {
	
	int u_m_no;
	String u_m_id;
	String u_m_pw;
	String u_m_name;
	String u_m_gender;
	String u_m_mail;
	String u_m_phone;
	String u_m_reg_date;
	String u_m_mod_date;
	public int getU_m_no() {
		return u_m_no;
	}
	public void setU_m_no(int u_m_no) {
		this.u_m_no = u_m_no;
	}
	public String getU_m_id() {
		return u_m_id;
	}
	public void setU_m_id(String u_m_id) {
		this.u_m_id = u_m_id;
	}
	public String getU_m_pw() {
		return u_m_pw;
	}
	public void setU_m_pw(String u_m_pw) {
		this.u_m_pw = u_m_pw;
	}
	public String getU_m_name() {
		return u_m_name;
	}
	public void setU_m_name(String u_m_name) {
		this.u_m_name = u_m_name;
	}
	public String getU_m_gender() {
		return u_m_gender;
	}
	public void setU_m_gender(String u_m_gender) {
		this.u_m_gender = u_m_gender;
	}
	public String getU_m_mail() {
		return u_m_mail;
	}
	public void setU_m_mail(String u_m_mail) {
		this.u_m_mail = u_m_mail;
	}
	public String getU_m_phone() {
		return u_m_phone;
	}
	public void setU_m_phone(String u_m_phone) {
		this.u_m_phone = u_m_phone;
	}
	public String getU_m_reg_date() {
		return u_m_reg_date;
	}
	public void setU_m_reg_date(String u_m_reg_date) {
		this.u_m_reg_date = u_m_reg_date;
	}
	public String getU_m_mod_date() {
		return u_m_mod_date;
	}
	public void setU_m_mod_date(String u_m_mod_date) {
		this.u_m_mod_date = u_m_mod_date;
	}
	
	
	
}
