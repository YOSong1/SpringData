package com.boot.batis.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Setter
@Getter
public class Test {

    private String first_name;
    private String last_name;

}
