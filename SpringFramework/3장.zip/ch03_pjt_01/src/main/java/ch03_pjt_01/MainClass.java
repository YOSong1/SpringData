package ch03_pjt_01;
public class MainClass {
    public static void main(String[] args) {
        
        TransportationWalk transportationWalk = new TransportationWalk();
        transportationWalk.move();
        
    }
}