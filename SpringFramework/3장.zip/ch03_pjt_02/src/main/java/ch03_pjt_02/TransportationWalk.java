package ch03_pjt_02;
public class TransportationWalk {
    public void move() {
        
        System.out.println("도보로 이동합니다!");
        
    }
}