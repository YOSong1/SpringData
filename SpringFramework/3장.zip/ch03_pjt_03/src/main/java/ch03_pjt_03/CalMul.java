package ch03_pjt_03;
public class CalMul implements ICalculator {
    public int doOperation(int firstNum, int secondNum) {
        return firstNum * secondNum;
    }
}