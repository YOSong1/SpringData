package ch03_pjt_03;
public class CalSub implements ICalculator {
    public int doOperation(int firstNum, int secondNum) {
        return firstNum - secondNum;
    }
}