package ch03_pjt_03;
public interface ICalculator {

    public int doOperation(int firstNum, int secondNum);

}