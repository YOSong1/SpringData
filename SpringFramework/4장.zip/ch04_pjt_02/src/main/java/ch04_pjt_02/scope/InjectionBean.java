package ch04_pjt_02.scope;

public class InjectionBean {

}
