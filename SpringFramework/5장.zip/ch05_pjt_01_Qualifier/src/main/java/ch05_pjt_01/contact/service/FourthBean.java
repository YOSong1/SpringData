package ch05_pjt_01.contact.service;

public class FourthBean {

}
