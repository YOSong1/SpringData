package ch02_pjt_01;
public class MainClass {
    public static void main(String[] args) {	
        new CalAssembler();	
    }
}